import Cocoa

let actor = "Jennifer Aniston"
let filename = "filename.swift"
let result = "⭐️ You win! ⭐️"

let quote = "Then he tapped a sign \"believe\" and walked away"


let movie = """
A day in
the life of an
Apple engineer
"""

print(actor.count)

let namelength = actor.count
print(namelength)

print(result.uppercased())

print(movie.hasPrefix("A day"))

print(filename.hasSuffix(".swift"))

