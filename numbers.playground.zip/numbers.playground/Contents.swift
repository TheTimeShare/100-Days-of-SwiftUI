import Cocoa

let score = 10

let reallyBig = 1000000000

let reallyreallyBig = 100_000_000


let lowerScore = score - 2
let higherScore = score + 10
let doubledScore = score * 2
let squaredScore = score * score
let halvedScore = score / 2
print(score)


var counter = 10
counter = counter + 5
counter += 10
print(counter)

counter *= 2
print(counter)
counter += 5
print(counter)
counter /= 2
print(counter)

let number = 120
print(number.isMultiple(of: 3))

print(120.isMultiple(of: 3))

